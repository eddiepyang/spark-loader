from pathlib import Path

file_path = Path(__file__)
root = file_path.parent.parent.absolute()
